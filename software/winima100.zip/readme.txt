

                                 WINIMAGE 10.00
                      Copyright 1993-2020 Gilles Vollant



For Windows Windows XP/Vista/seven/8/10


there is two new feature on 10.0:
- WinImage can open vhd image with GPT/GUID partitions


PURPOSE
~~~~~~~
This Zipfile contains WinImage 10.00, standard and professional
version, and the self extractor.

This is the English version of WinImage 10.00. For other languages,
you need to download the translation Zipfile on the WinImage Internet
Web site http://www.winimage.com/download.htm .


STEP ONE
~~~~~~~~
You need to extract zipfile in a new directory (for example,
c:\winimage). You can use WinZip (http://www.winzip.com) for this
task.

You can also start the install file winima100.exe.



STEP TWO
~~~~~~~~
If you want to run WinImage, just run WinImage.exe.

The full documentation is in the WinImage.chm help file. The additional
features of WinImage 10.00 are in the "Evolution of WinImage topic".

Don't hesitate check the web site for up-to-date info.


Gilles Vollant
mailto:info@winimage.com
http://www.winimage.com
http://www.winimage.com/order.htm (for ordering a license)
