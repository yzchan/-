
void main()
{

	char arr[] = "abc";
	char* arr1 = "123";

}
